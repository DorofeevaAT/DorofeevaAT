package com.example.lab5;

public class Cat {
    String name = "";
    String type = "";
    Integer id = 0;

    public Cat(String name, String type, Integer id) {
        this.name = name;
        this.type = type;
        this.id = id;
    }

    public Cat() {
    }
}
