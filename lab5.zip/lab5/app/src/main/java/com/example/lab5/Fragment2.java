package com.example.lab5;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class Fragment2 extends Fragment implements Fragment2Adapter.ItemClickListener{
    Fragment2Adapter adapter;
    List<Cat> items = new ArrayList<>();

    Button addNewCat;
    Button refreshCatList;

    APIInterface apiInterface;

    Fragment2() {
        super(R.layout.fragment2_layout);
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment2_layout, container, false);

        addNewCat = rootView.findViewById(R.id.f2_bac);
        refreshCatList = rootView.findViewById(R.id.f2_brc);

        refreshCatList.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                getData();
            }
        });

        addNewCat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DialogFragment addCatFragment = new FragmentAddCatDialog();
                addCatFragment.show(getActivity().getSupportFragmentManager(), "ADD_CAT");
            }
        });

        RecyclerView recyclerView =rootView.findViewById(R.id.recyclerView);

        getData();

        recyclerView.setLayoutManager(new LinearLayoutManager(this.getContext()));
        adapter = new Fragment2Adapter(this.getContext(), items);
        adapter.setClickListener(this);
        recyclerView.setAdapter(adapter);

        return rootView;
    }

    @Override
    public void onItemClick(View view, int position) {
        Cat cat = items.get(position);
        System.out.println("ID: " + cat.id + " " + "Имя: " + cat.name + " " + "Порода: " + cat.type);
        Toast.makeText(getActivity(), "ID: " + cat.id + " " + "Имя: " + cat.name + " " + "Порода: " + cat.type, Toast.LENGTH_SHORT).show();
    }

    public void getData() {
        apiInterface = APIClient.getClient().create(APIInterface.class);
        Call<List<Cat>> call = apiInterface.getCatList();

        call.enqueue(new Callback<List<Cat>>() {
            @Override
            public void onResponse(Call<List<Cat>> call, Response<List<Cat>> response) {
                List<Cat> cats = response.body();
                items.clear();
                items.addAll(cats);

                adapter.notifyDataSetChanged();
            }

            @Override
            public void onFailure(Call<List<Cat>> call, Throwable t) {
                Toast.makeText(getActivity(), "Похоже мы потеряли соединение..", Toast.LENGTH_SHORT).show();
            }
        });
    }
}