package com.example.lab5;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.POST;

public interface APIInterface {
    @GET("/cat")
    Call<List<Cat>> getCatList();

    @GET("/cat/?")
    Call<Cat> getCatById();

    @POST("/cat")
    Call<Cat> createCat(@Body Cat cat);
}
