package com.example.lab5;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.DialogFragment;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class FragmentAddCatDialog extends DialogFragment {

    EditText editCatName;
    EditText editCatType;
    EditText editCatId;

    APIInterface apiInterface;

    @NonNull
    @Override
    public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        LayoutInflater inflater = requireActivity().getLayoutInflater();
        View view = inflater.inflate(R.layout.add_cat_dialog_layout, null);
        builder.setView(view);

        editCatName = view.findViewById(R.id.fg_add_cat_name);
        editCatType = view.findViewById(R.id.fg_add_cat_type);
        editCatId = view.findViewById(R.id.fg_add_cat_id);

        apiInterface = APIClient.getClient().create(APIInterface.class);

        builder.setMessage("Мяу!");
        builder.setPositiveButton("Добавить", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                Integer catId = 0;
                try {
                    catId = Integer.parseInt(editCatId.getText().toString());
                }
                catch (Exception e) {
                    Toast.makeText(getActivity(), "эй число должно быть целым!", Toast.LENGTH_SHORT).show();
                }
                String catName = editCatName.getText().toString();
                String catType = editCatType.getText().toString();

                Call<Cat> call = apiInterface.createCat(new Cat(catName, catType, catId));
                    call.enqueue(new Callback<Cat>() {
                        @Override
                        public void onResponse(Call<Cat> call, Response<Cat> response) {
                            Toast.makeText(getActivity(), "Котик в списке!", Toast.LENGTH_SHORT).show();
                        }

                        @Override
                        public void onFailure(Call<Cat> call, Throwable t) {
                            Toast.makeText(getActivity(), "Что-то пошло не так :(", Toast.LENGTH_SHORT).show();
                        }
                    });
                            System.out.println("Добавить" + catId + "/" + catName + "/" + catType);
            }
        });
        builder.setNegativeButton("Передумал..", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                System.out.println("Отмена");
            }
        });
        return builder.create();
    }
}
