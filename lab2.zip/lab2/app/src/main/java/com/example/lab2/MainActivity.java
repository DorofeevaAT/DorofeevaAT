package com.example.lab2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

 public class MainActivity extends AppCompatActivity {



     @Override
     protected void onCreate(Bundle savedInstanceState) {
         super.onCreate(savedInstanceState);
         setContentView(R.layout.activity_main);

         TextView textViewDate;
         Button buttonGetDate;
         textViewDate = findViewById(R.id.fr1_tdate);
         buttonGetDate = findViewById(R.id.f1_b1date);

         buttonGetDate.setOnClickListener(new View.OnClickListener() {
             @Override
             public void onClick(View view) {
                 DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
                 Calendar cal = Calendar.getInstance();
                 Date currentDate = cal.getTime();
                 textViewDate.setText(dateFormat.format(currentDate));
             }
         });
     }
 }