from Cat import Cat

class CatStorage:
    catsArray = []

    def __init__(self):
        print("Storage initialized")

    def fill_init_cats(self) -> None:
        print("fill_init_cats called")
        cat1 = Cat("Сонечка", "Путешественница", 1)
        cat2 = Cat("Андрюшка", "Музыкальный", 2)
        cat3 = Cat("Макарик", "Персидский", 3)

        self.catsArray.append(cat1)
        self.catsArray.append(cat2)
        self.catsArray.append(cat3)

    def get_all_cats(self) -> []:
        return self.catsArray

    def add_cat(self, cat):
        self.catsArray.append(cat)