import json

from flask import Flask, request
from CatStorage import CatStorage
from Cat import Cat

class CustomEncoder(json.JSONEncoder):
    def default(self, o):
        return o.__dict__

app = Flask(__name__)
cat_storage = None

@app.route('/cat', methods = ['GET'])
def get_all_cats():
    return json.dumps(cat_storage.get_all_cats(), indent=4, cls=CustomEncoder)

@app.route('/cat', methods = ['POST'])
def create_cat():
    print("Add cat called")
    request_data = request.get_json()
    c_name = request_data["name"]
    c_type = request_data["type"]
    c_id = request_data["id"]
    cat = Cat(c_name, c_type, c_id)
    cat_storage.add_cat(cat)
    return json.dumps(cat, indent=4, cls=CustomEncoder)

if __name__ == '__main__':
    print('started')
    cat_storage = CatStorage()
    cat_storage.fill_init_cats()
    app.run()